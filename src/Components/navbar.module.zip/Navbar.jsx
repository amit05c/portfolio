import React, { useState } from 'react'
// import { Link } from 'react-router-dom'
import * as Scroll from 'react-scroll';
import { Link, Button, Element, Events, animateScroll as scroll, scrollSpy, scroller } from 'react-scroll'
import styles from "./navbar.module.css"
import { GiHamburgerMenu } from "react-icons/gi";

const Navbar = () => {
    const [showMediaIcons, setShowMediaIcons] = useState(false);

  return (
    <div className={styles.main_nav}>

<div className={`${styles.hamburger_menu}`}>
            <a href="#" onClick={() => setShowMediaIcons(!showMediaIcons)}>
              <GiHamburgerMenu />
            </a>
          </div>

    <div className={showMediaIcons ? styles.mobile_view : styles.navbar }
        
    >
        <Link to="about" spy={true} smooth={true} offset={50} duration={500}
        // onClick={closeMenu} 
        className={styles.help}
        >About</Link>
        <Link to="projects" spy={true} smooth={true} offset={50} duration={500} className={styles.help}>Projects</Link>
        <Link to="skills" spy={true} smooth={true} offset={50} duration={500} className={styles.help}>Skills</Link>
    </div>
      
    

    </div>

  )
}

export default Navbar